bitBangedSPI
============

SPI class for Arduino Uno and similar.

For details and documentation see:

http://www.gammon.com.au/forum/?id=10892

In particular: 

http://www.gammon.com.au/forum/?id=10892&reply=6#reply6
